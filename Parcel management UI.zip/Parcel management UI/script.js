document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const userIDInput = document.getElementById('userID');
    const passwordInput = document.getElementById('password');
    const errorDiv = document.getElementById('error');
  
    loginForm.addEventListener('submit', function(event) {
      event.preventDefault(); // Prevent the form from submitting
  
      // Reset error message
      errorDiv.innerText = '';
  
      // Get the values from the inputs
      const userID = userIDInput.value.trim();
      const password = passwordInput.value.trim();
  
      // Validate user ID
      if (userID.length < 5 || userID.length > 20) {
        showError('User ID must be between 5 and 20 characters.');
        return;
      }
  
      // Validate password
      const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{1,30}$/;
      if (!passwordRegex.test(password)) {
        showError('Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character.');
        return;
      }
  
      // Simulate successful login (redirect to dashboard)
      redirectToDashboard();
    });
  
    function showError(message) {
      errorDiv.innerText = message;
    }
  
    function redirectToDashboard() {
      // Simulate redirect to dashboard (replace 'dashboard.html' with your actual dashboard page)
      window.location.href = 'dashboard.html';
    }
  });
  
  